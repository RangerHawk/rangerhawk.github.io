#!/usr/bin/env python3

import gi
gi.require_version("Gimp", "3.0")
gi.require_version("GimpUi", "3.0")

import sys, os, time, json, base64
from gi.repository import Gimp, GimpUi, Gegl, GObject, GLib, Gio, Gtk

# ─── Logging ────────────────────────────────────────────────────────────────

def log_event(msg):
    path = os.path.join(os.path.dirname(__file__), "gimpinator_log.txt")
    with open(path, "a", encoding="utf-8") as f:
        f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")

log_event("Log File Locked and Loaded")
log_event("Global scope executing...")
log_event(f"Python executable: {sys.executable}")

# ─── Finding 'requests' ─────────────────────────────────────────────────────
# 24 Oct 2026 fix: no hardcoded username anymore. GIMP 3's own bundled Python
# doesn't automatically see packages pip-installed into a regular Windows
# Python install, so this used to require every user to hand-edit this file
# with their own Windows username. Fixed two ways instead, neither needing an
# edit:
#   1. A bundled copy of 'requests' under ./vendor/, if one is shipped here.
#   2. Otherwise, search the CURRENT user's own AppData for any installed
#      Python 3.x and add its site-packages -- found via the LOCALAPPDATA
#      environment variable, which always points at the right place for
#      whoever is actually running GIMP, never a baked-in name.

vendor = os.path.join(os.path.dirname(__file__), "vendor")
if vendor not in sys.path:
    sys.path.insert(0, vendor)

try:
    import requests
    from datetime import datetime
    log_event(f"Imported requests from vendor folder: {vendor}")
except ImportError:
    requests = None
    if os.name == "nt":
        import glob
        appdata_local = os.environ.get("LOCALAPPDATA", "")
        found = []
        if appdata_local:
            found = glob.glob(os.path.join(appdata_local, "Programs", "Python", "Python3*", "Lib", "site-packages"))
        for site_packages in found:
            if site_packages not in sys.path:
                sys.path.append(site_packages)
        try:
            import requests
            from datetime import datetime
            log_event(f"Imported requests via discovered site-packages: {found}")
        except ImportError:
            requests = None
            log_event(f"Could not import requests. Checked vendor/ and: {found}. "
                       f"Run: pip install requests")
    else:
        log_event("Could not import requests. Run: pip install requests")


# ─── Config helpers ─────────────────────────────────────────────────────────

def read_config(config):
    log_event("Reading config")
    params = {
        "backend": config.get_property("backend").lower(),
        "prompt": config.get_property("prompt"),
        "model": config.get_property("model"),
        "width": int(config.get_property("width")),
        "height": int(config.get_property("height")),
        "steps": int(config.get_property("steps")),
        "guidance": float(config.get_property("guidance")),
        "seed": int(config.get_property("seed")),
        "timeout": int(config.get_property("timeout")),
        "splash": bool(config.get_property("splash")),
    }
    log_event(f"Config read: {params}")
    return params


def validate_mandatory_params(params):
    mandatory_keys = ["backend", "prompt", "model"]
    for key in mandatory_keys:
        if not params.get(key):
            log_event(f"Missing mandatory value for {key}")
            raise ValueError(f"Mandatory parameter {key} is missing.")


def debug_config_properties(params):
    log_event("Debugging config properties:")
    for key, value in params.items():
        log_event(f"  {key}: {value}")


# ─── Main entry point ───────────────────────────────────────────────────────

def gimpinate(proc, run_mode, image, drawables, config, data):
    log_event(f"Invoked -- run_mode={run_mode}")

    if run_mode == Gimp.RunMode.INTERACTIVE:
        GimpUi.init("python-fu-gimpinator")
        dlg = GimpUi.ProcedureDialog(procedure=proc, config=config)
        dlg.fill(None)
        if not dlg.run():
            dlg.destroy()
            log_event("Dialog canceled")
            return proc.new_return_values(Gimp.PDBStatusType.CANCEL, GLib.Error())
        dlg.destroy()

    params = read_config(config)
    log_event(f"Loaded params after dialog: {params}")

    try:
        validate_mandatory_params(params)
    except ValueError as e:
        log_event(f"Validation failed: {e}")
        return proc.new_return_values(Gimp.PDBStatusType.EXECUTION_ERROR, GLib.Error())

    debug_config_properties(params)

    backend = params["backend"]
    try:
        log_event(f"Routing to backend: {backend}")
        if backend == "horde":
            run_horde_backend(params, image)
        elif backend == "local":
            run_local_backend(params, image)
        else:
            log_event(f"Unknown backend: {backend!r} (expected 'horde' or 'local')")
            return proc.new_return_values(Gimp.PDBStatusType.EXECUTION_ERROR, GLib.Error())
    except Exception as e:
        log_event(f"Routing failed: {e}")
        return proc.new_return_values(Gimp.PDBStatusType.EXECUTION_ERROR, GLib.Error())

    return proc.new_return_values(Gimp.PDBStatusType.SUCCESS, GLib.Error())


# ─── STABLE HORDE ────────────────────────────────────────────────────────────

def run_horde_backend(params, image):
    log_event("Running Horde backend...")

    if not requests:
        log_event("Horde backend needs the 'requests' package, which could not be imported.")
        raise RuntimeError("Missing 'requests' package -- see gimpinator_log.txt")

    api_key = params.get("api_key") or os.environ.get("HORDE_API_KEY", "")
    if not api_key:
        api_key = _read_config_file_api_key()
    if not api_key:
        log_event("No Stable Horde API key found (config file, HORDE_API_KEY env var)")
        raise ValueError("Missing Stable Horde API key -- see gimpinator_config.json")

    prompt   = params["prompt"]
    width    = params["width"]
    height   = params["height"]
    steps    = params["steps"]
    guidance = params["guidance"]
    seed     = str(params["seed"])
    timeout  = params["timeout"]

    endpoint = "https://stablehorde.net/api/v2/generate/async"
    status_url = "https://stablehorde.net/api/v2/generate/status"

    payload = {
        "prompt": prompt,
        "params": {
            "width": width,
            "height": height,
            "steps": steps,
            "cfg_scale": guidance,
            "seed": seed,
            "sampler_name": "k_euler_a",
        },
    }
    headers = {"apikey": api_key, "Content-Type": "application/json"}

    log_event(f"Horde queue request: {payload}")

    try:
        response = requests.post(endpoint, json=payload, headers=headers, timeout=timeout)
        response.raise_for_status()
        json_data = response.json()
        log_event(f"Horde response: {json_data}")

        job = json_data.get("id")
        if not job:
            raise ValueError(f"Horde response missing job ID: {json_data}")
        log_event(f"Job submitted -- ID: {job}")

        img_data = None
        poll_interval = 5
        max_polls = max(1, timeout // poll_interval)
        for _ in range(max_polls):
            time.sleep(poll_interval)
            s = requests.get(f"{status_url}/{job}", headers=headers, timeout=30)
            js = s.json()
            log_event(f"Horde job {job} queue_position={js.get('queue_position')} done={js.get('done')}")

            if js.get("done") and js.get("generations"):
                gen = js["generations"][0]
                image_field = gen.get("img")
                if not image_field:
                    raise ValueError("No image found in Horde generation")
                if image_field.startswith("http"):
                    log_event("Detected image URL -- downloading...")
                    img_data = requests.get(image_field, timeout=60).content
                else:
                    img_data = base64.b64decode(image_field)
                break

        if not img_data:
            raise TimeoutError(f"Horde job {job} did not finish within {timeout}s")

        ai_dir = os.path.join(os.path.dirname(__file__), "ai")
        os.makedirs(ai_dir, exist_ok=True)
        out = os.path.join(ai_dir, "horde.png")
        with open(out, "wb") as f:
            f.write(img_data)

        gfile = Gio.File.new_for_path(out)
        layer = Gimp.file_load_layer(Gimp.RunMode.NONINTERACTIVE, image, gfile)
        layer.set_name(prompt[:20])
        image.insert_layer(layer, None, 0)
        log_event("Inserted Horde image")

    except Exception as e:
        log_event(f"Horde error: {e}")
        raise


def _read_config_file_api_key():
    cfg_path = os.path.join(os.path.dirname(__file__), "gimpinator_config.json")
    if not os.path.exists(cfg_path):
        return ""
    try:
        with open(cfg_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        key = cfg.get("api_key", "")
        return key if key and key != "your-key-here" else ""
    except Exception as e:
        log_event(f"Could not read gimpinator_config.json: {e}")
        return ""


# ─── LOCAL ───────────────────────────────────────────────────────────────────

def run_local_backend(params, image):
    log_event("Running Local backend...")

    if not requests:
        log_event("Local backend needs the 'requests' package, which could not be imported.")
        raise RuntimeError("Missing 'requests' package -- see gimpinator_log.txt")

    prompt   = params["prompt"]
    model    = params["model"]
    width    = params["width"]
    height   = params["height"]
    steps    = params["steps"]
    guidance = params["guidance"]
    seed     = str(params["seed"])
    timeout  = params["timeout"]

    payload = {
        "prompt": prompt, "model": model,
        "width": width, "height": height,
        "steps": steps, "guidance": guidance,
        "seed": seed,
    }
    log_event("Local payload:\n" + json.dumps(payload, indent=2))

    r = requests.post("http://127.0.0.1:8000/generate", json=payload, timeout=timeout)
    r.raise_for_status()
    log_event("Local response: " + r.text[:500])
    d = r.json()
    img = d.get("image_path") or d.get("image") or d.get("path")
    if not img or not os.path.exists(img):
        raise FileNotFoundError(f"Local backend did not return a usable image path: {img!r}")

    gfile = Gio.File.new_for_path(img)
    layer = Gimp.file_load_layer(Gimp.RunMode.NONINTERACTIVE, image, gfile)
    layer.set_name(prompt[:20])
    image.insert_layer(layer, None, 0)
    log_event("Inserted local image")


# ─── Plugin registration ────────────────────────────────────────────────────

class Gimpinator(Gimp.PlugIn):
    def do_query_procedures(self):
        return ["python-fu-gimpinator"]

    def do_create_procedure(self, name):
        log_event("Registering Gimpinator EX")
        Gegl.init(None)
        proc = Gimp.ImageProcedure.new(self, name,
            Gimp.PDBProcType.PLUGIN, gimpinate, None)
        proc.set_image_types("*")
        proc.set_menu_label("Gimpinator EX")
        proc.add_menu_path("<Image>/Filters/Gimpinator")
        proc.set_documentation(
            "Generate an AI image from a prompt",
            "AI image generation via Stable Horde or a local backend",
            "https://github.com/RangerHawk/Gimpinator-EX-Gimp-3"
        )
        proc.set_attribution("RangerHawk Studios", "RangerHawk Studios", "2026")

        proc.add_string_argument(
            "prompt", "_Prompt", "Describe the image", "", GObject.ParamFlags.READWRITE
        )
        proc.add_string_argument(
            "backend", "_Backend", "Type 'horde' or 'local'",
            "horde", GObject.ParamFlags.READWRITE
        )
        proc.add_string_argument(
            "model", "_Model", "AI model name", "DreamShaper v8", GObject.ParamFlags.READWRITE
        )
        proc.add_int_argument("width", "_Width (px)", "Image width", 64, 2048, 1024, GObject.ParamFlags.READWRITE)
        proc.add_int_argument("height", "_Height (px)", "Image height", 64, 2048, 1024, GObject.ParamFlags.READWRITE)
        proc.add_int_argument("steps", "_Steps", "Inference steps", 1, 150, 30, GObject.ParamFlags.READWRITE)
        proc.add_double_argument("guidance", "_Guidance", "Prompt guidance (CFG scale)", 1.0, 30.0, 7.5, GObject.ParamFlags.READWRITE)
        proc.add_int_argument("seed", "_Seed", "Random seed (0 = random)", 0, 2147483647, 0, GObject.ParamFlags.READWRITE)
        proc.add_int_argument("timeout", "_Timeout (s)", "Request/queue timeout in seconds", 10, 600, 120, GObject.ParamFlags.READWRITE)
        proc.add_boolean_argument("splash", "_Splash", "Add splash layer", True, GObject.ParamFlags.READWRITE)

        return proc

Gimp.main(Gimpinator.__gtype__, sys.argv)
